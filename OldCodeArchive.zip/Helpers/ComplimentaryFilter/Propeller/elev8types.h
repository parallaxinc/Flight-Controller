#ifndef __ELEV8_TYPES_H__
#define __ELEV8_TYPES_H__

typedef unsigned char u8;
typedef unsigned short u16;


#endif
